#include<new>
#include<math.h>
#include<iostream>
#include<vector>

#include"header.h"
#include"Mersenne.h"

float get_sp_event(int *sp, int *event, int number_sp, float *gamma, int *k, float *ne, float *sel_coef, float *r);

void make_prelim_graph(std::vector< float* > *tree, int number_sp, int *sample_size, float *sel_coef, float *r, int *num_intr, float t_max, 
						float *ne, float *gamma, int *num_coal, int *num_sel, int *num_rec, int *num_other,
						int block_size, std::vector< int* > *block_start_stop) {
	
	float t = 0.0;
	float total_rate = 0.0;

	int node_count_for_block = 0;
	int node_count_tot = 0;
	
	int block_start = 0;
	
	int *k = new int[number_sp];
	int k_sum = 0;
	for(int i = 0; i <= number_sp - 1; i++)	{
		k[i] = sample_size[i];
		k_sum = k_sum + k[i];
		for(int j = 0; j <= sample_size[i] - 1; j++) {
			float *graph_info;
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 0.0;
			graph_info[2] = float(i);
			graph_info[3] = 1;
			tree->push_back(graph_info);
		
			node_count_tot = node_count_tot + 1;
			node_count_for_block = node_count_for_block + 1;
		}
	}
	
	*num_coal = 0;
	*num_sel = 0;
	*num_rec = 0;
	*num_other = 0;
	
	int *num_event_sp = new int[number_sp];
	for(int i = 0; i <= number_sp - 1; i++)	num_event_sp[i] = 0;
	
	while(t < t_max /*&& k_sum > number_sp*/)	{													
				
		int sp;
		int event;
		total_rate = get_sp_event(&sp, &event, number_sp, gamma, k, ne, sel_coef, r);
		t += -1.0 * log(1.0 -  genrand_real3())/total_rate;
		
		num_event_sp[sp] = num_event_sp[sp] + 1;
																	
		if(event == 0)	{
			/* Coalescent event */
			float *graph_info;
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 1.0;
			graph_info[2] = float(sp);
			graph_info[3] = 1;
			tree->push_back(graph_info);
			
			k[sp] = k[sp] - 1;
			*num_coal = *num_coal + 1;
			
			node_count_tot = node_count_tot + 1;
			node_count_for_block = node_count_for_block + 1;
		}
		
		else if(event == 1)	{
			/* Selection Event */
			float *graph_info;
			
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 2.0;
			graph_info[2] = float(sp);
			graph_info[3] = 0;
			tree->push_back(graph_info);
			
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 2.0;
			graph_info[2] = float(sp);
			tree->push_back(graph_info);
			
			if(genrand_real3() < float(k[sp])/ne[sp])
				/* Do not increment k[sp] up because selection corresponds to a simultaneous coalescent event */
				graph_info[3] = 1;
			else	{
				graph_info[3] = 0;
				k[sp] = k[sp] + 1;
			}
			
			for(int i = 0; i <= number_sp - 1; i++)	{
				for(int ind = 0; ind <= num_intr[sp * number_sp + i] - 1; ind++)	{
					graph_info = new float[4];
					graph_info[0] = t;
					graph_info[1] = 2.0;
					graph_info[2] = float(i);
					tree->push_back(graph_info);
					
					if(genrand_real3() < float(k[i])/ne[i])
						/* Do not increment k[i] up because interaction corresponds to a simultaneous coalescent event */
						graph_info[3] = 1;
					else	{
						graph_info[3] = 0;
						k[i] = k[i] + 1;
					}
				}
				
				node_count_tot = node_count_tot + num_intr[sp * number_sp + i];
				node_count_for_block = node_count_for_block + num_intr[sp * number_sp + i];
			}
			
			*num_sel = *num_sel + 1;
			
			node_count_tot = node_count_tot + 2;
			node_count_for_block = node_count_for_block + 2;
		}
		else if(event == 2)	{
			/* Recombination Event */
			
			float *graph_info;
			
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 4.0;
			graph_info[2] = float(sp);
			graph_info[3] = 0;
			tree->push_back(graph_info);
			
			graph_info = new float[4];
			graph_info[0] = t;
			graph_info[1] = 4.0;
			graph_info[2] = float(sp);
			tree->push_back(graph_info);
			
			if(genrand_real3() < float(k[sp])/ne[sp])
				/* Do not increment k[sp] up because recombination corresponds to a simultaneous coalescent event */
				graph_info[3] = 1;
			else	{
				graph_info[3] = 0;
				k[sp] = k[sp] + 1;
			}
			
			*num_rec = *num_rec + 1;
			
			node_count_tot = node_count_tot + 2;
			node_count_for_block = node_count_for_block + 2;
			
		}
		else	{
			std::cout << "Error determining if a coal or selection or recombination event occurred." << std::endl;
			exit(8);
		}
		
		k_sum = 0;
		for(int i = 0; i <= number_sp - 1; i++)	k_sum = k_sum + k[i];
		
		if((node_count_for_block >= block_size && node_count_for_block >= k_sum) ||
				t >= t_max /*|| k_sum == number_sp*/)	{
			/* Graph Slice */

			int *block_info;
			block_info = new int[2];
			
			block_info[0] = block_start;
			block_start = node_count_tot;

			for(int i = 0; i <= k_sum - 1; i++)	{
				float *graph_info;
			
				graph_info = new float[4];
				graph_info[0] = t;
				graph_info[1] = 3.0;
				graph_info[2] = -1.0;
				graph_info[3] = 1;
				tree->push_back(graph_info);
				
				node_count_tot = node_count_tot + 1;
				*num_other = *num_other + 1;
			}
			
			block_info[1] = node_count_tot;
			block_start_stop->push_back(block_info);

			node_count_for_block = 0;
			
		}
	}
	
	for(int i = 0; i <= number_sp - 1; i++)	std::cout << float(num_event_sp[i])/float(*num_coal + *num_sel + *num_rec) << std::endl;
	
	delete[] k;
	delete[] num_event_sp;
	
	std::cout << "Exiting make_prelim_graph: " << t << std::endl;
	return;
}
			
float get_sp_event(int *sp, int *event, int number_sp, float *gamma, int *k, float *ne, float *sel_coef, float *r)	{
	float ran_dev = 0.0;
	ran_dev = genrand_real3();
	
	float total_rate = 0.0;
	float *sp_coal_loc = new float[number_sp];
	float *sp_sel_loc = new float[number_sp];
	float *sp_rec_loc = new float[number_sp];
	for(int i = 0; i <= number_sp - 1; i++)	{
		total_rate = total_rate + gamma[i] * float(k[i]) * (float(k[i]) - 1.0)/(2.0 * ne[i]);
		sp_coal_loc[i] = total_rate;
		total_rate = total_rate + gamma[i] * float(k[i]) * sel_coef[i]/2.0;
		sp_sel_loc[i] = total_rate;
		total_rate = total_rate + gamma[i] * float(k[i]) * r[i]/2.0;
		sp_rec_loc[i] = total_rate;
	}
	
	*sp = -1;
	*event = -1;
	
	for(int i = 0; i <= number_sp - 1; i++)	{
	
		if (ran_dev <= sp_coal_loc[i]/total_rate)	{
			*sp = i;
			*event = 0;
			break;
		}
		else if (ran_dev > sp_coal_loc[i]/total_rate && ran_dev <= sp_sel_loc[i]/total_rate)	{
			*sp = i;
			*event = 1;
			break;
		}
		else if (ran_dev > sp_sel_loc[i]/total_rate && ran_dev <= sp_rec_loc[i]/total_rate)	{
			*sp = i;
			*event = 2;
			break;
		}
		else	{
			*sp = -1;
			*event = -1;
		}
		
	}
	
	if(*sp == -1 || *event == -1)	{
		std::cout << "Error in get_sp_event." << std::endl;
		exit(8);
	}
	
	delete[] sp_coal_loc;
	delete[] sp_sel_loc;
	delete[] sp_rec_loc;
	
	return total_rate;
	
}