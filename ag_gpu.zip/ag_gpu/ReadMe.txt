The program can be compiled using the following command:

Apple OS

g++ -o name_of_executable *.c *.cpp -framework OpenCL

Although Apple has deprecated OpenCL, it still supports compiling an running OpenCL up to a particular release.  We have had success compiling and running on Ventura using Xcode command-line tools on an Apple M2 chip.  ag_gpu_sim does not use functionality beyond release 1.2 of OpenCL, which Apple appears to support, presently.

Linux & Unix

g++ -o name_of_executable *.c *.cpp -lOpenCL

Note, this assumes the OpenCL libraries are installed and within an accessible PATH in Linux and Unix.

*********************************

The program is executed as

./name_of_executable seed_for_random_number_generation

The seed_for_random_number_generation is a long integer.

Note the cl_files folder must be copied into folders with the executable for the program to run.  

This cl_files folder contains the GPU kernels. 

*********************************

The program expects a parameter.dat file in the same folder as the executable.  The order of parameters in the file is required to be

number of replicates
number of species (or labels)					#For this paper, equal to 1, or if >1, then species are equivalent and 
								#is an approach to run multiple replicates on a GPU simultaneously

#If the following set of parameters are repeated in blocks, then multiple replicates are processed simultaneously on a GPU
#Begin for a species or label
sample size 
effective population size 
s
r
relative species generation time				#For this paper, equal to 1, labeled gamma in program code
number of interacting individuals per selection event		#For this paper, equal to 0	
mu_+
mu_-
core or marker locus mutation rate				#Not studied in this paper, set to 5.e-7
alpha								#Where alpha corresponds to paper, labeled a_0 in program code
a_1 (selection parameter for core/marker locus)			#Not used in this paper, set to 0
a_2 (selection parameter involving interactions)		#Not used in this paper, set to 0
beta or delta (depending on the state of parameter a_4)
a_4 (indicator parameter for genome size evolution)		#A value of "0" corresponds to "Model 1" and value of "1" corresponds to "Model 2"
#End for a species or label

recombination (0) or hgt (1) indicator
gamma								#Where gamma corresponds to paper, labeled alpha in program code

T
number of sets of accessory genes			
number of sets of core/marker sites				#For this paper, set to 1

number of 15 gene subsets of accessory genes			#Note the number of sets of accessory genes
								#times the number of subsets times 15 equals
								#the size of the accessory gene pool
								#
								#The gene pool is divided into sets and
								#subsets for efficient memory use.  

number of 15 site subsets of core/marker sites			#For this paper, set to 1
number of subsets with adaptive accessory genes			
bit representation of subset of adaptive genes			#If x genes are adaptive in a subset then
								#this parameter is equal to sum(2^i,x=1..x)
								#
								#For figure 2b there are 5000 adaptive genes
								#To encode this, 500 subsets harbour 
								#adaptive genes and the bit representation
								#for each subset is 2046 = sum(2^i,i=1..10)
number of local jobs per core on GPU				#Set to 1
number of total jobs per GPU 					#Set to the number of cores in a GPU
								#For a NVIDIA P100 it is 3584
number of cores on GPU						
indicator indicating when to check if graph slice is done	#See note [1]
number of nodes in graph to be processed by the GPU 		#See note [2]


[1] If the program returns a lot of the following output

"Calc x stats, Num positive nodes in cycle: 0, cycle: some_number that continually increases . . ."

then this parameter is too small.  Increment up.

[2] The program returns the following information

"Size of buffer to GPU: some_number"

if some_number is greater than the memory capacity of your GPU or even a bit less (in bytes), then decrease this parameter value.  Often the program will just exit if the capacity of the GPU is breached, but if you are close to the capacity of the GPU, it may just skip over calculations or truncate calculations.  

*****************************

Other notes:

[1] If you get the message

"The combination of graph size and number of genomic regions is too large.  Reduce the rate of selection or number of interacting individuals."

The preliminary graph is too large for your computer architecture and system (non-GPU) memory.  

The memory requirement of the program is approximately equal to the number of nodes in the graph times the data size of an integer.

Depending on your goals, decrease either the effective population size, s, or a combination of these.

[2] The ReadMe for the dACG program (Griswold 2022: Molecular Ecology; https://github.com/ckgriswold) discusses other points of practice and develop for this line of software.

My recommendation is to run a parameter set with a know outcome and that places a known load on the GPU.  If the results of this are accurate, then you can have confidence that the load on the GPU is acceptable.

****************************

Output files:

Data.out - Consists of the accessory genotypes of sampled individuals.  Genotypes are composed of L/15 subsets consisting of 15 accessory genes.  The genotype of a subset is encoded as an integer that can then be converted to a bit string (see .ipynb analysis file).  

Geno.out - Consists of the marker genotypes of sampled individuals.  The states of subsets of sites are encoded as an integer, which is then converted to a bit string like Data.out.

****************************

ipython analysis files:

ipython notebooks that were used to analyze simulation results are provided as supplements to the main paper.  In particular, the "analysis.ipynb" file includes functions that convert the integer representation of a subset of the accessory genome into its bit string and then assemble the full accessory genome.  These analysis files also calculate the gene frequency spectrum and other properties of a sample of accessory genomes.

****************************

The program uses the Mersenne Twister random number generator of Takuji Nishimura and Makoto Matsumoto (2002) for the serial generation of the ancestral graph, and the mwc64x random number generator of DA Thomas (2011) for GPU-associated processing of the graph.  Please refer to commented files for copyright notices.