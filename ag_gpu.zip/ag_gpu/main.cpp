#include<new>
#include<math.h>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<stdlib.h>
#include<vector>
#include <time.h> 

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

#include"header.h"
#include"Mersenne.h"
#include "dc.h"
#include "RanDev.h"

#define MAX_SOURCE_SIZE (0x100000)

int main(int argc, char *argv[])  {
	long seed = atol(argv[1]);
	init_genrand(seed);
	srand(seed);
	
	time_t t;
	
	/* Read in parameters from parameters.dat file.  Note order of parameters in code. */
	std::ifstream infilep("parameters.dat");
		if(!infilep) std::cerr << "Cannot open input file." << std::endl;
	
	int number_reps; 	infilep >> number_reps;		std::cout << number_reps << std::endl;		/* Number of replicates 			*/
	int number_sp;		infilep >> number_sp;		std::cout << number_sp << std::endl;		/* Number of species (or labels)	*/	
	/* Note, although "sp" is used indicating "species", this can be more generally interpreted as "label".			*/
	
	/* One can set number_sp to be greater than 1 and divide species (or labels) into subsets. 						*/
	
	/* Using this approach, multiple replicates of a subset can be run simultaneiously on a GPU, if the parameters 	*/
	/* between subsets are equal.  See ReadMe for more expanation.												   	*/
	
	int 	*sample_size 	= new int[number_sp];					/* Sample size per species or label							*/
	float 	*ne 			= new float[number_sp];					/* Effective population size per species or label			*/
	float 	*sel_coef 		= new float[number_sp];					/* Overall rate of selection per species or label			*/
	float 	*r		 		= new float[number_sp];					/* Overall rate of recombination or hgt . . .				*/
	float 	*gamma			= new float[number_sp];					/* Parameter associated with relative generation time		*/
	int 	*num_intr 		= new int[number_sp * number_sp];		/* Multi-array of number of interactions per selection 		*/
																	/* Row: focal species/label; Column: Interacting sp/lbl		*/
	float 	*acc_mu_gain 	= new float[number_sp];					/* Overall rate of gain of genes, or reverse mutation		*/
																	/* Note, the genome is divided into regions that are 		*/
																	/* potentially accessory.  Alternatively, these regions		*/
																	/* could be core and gain/loss reflects mutation, as 		*/
																	/* opposed to gene gain/loss.								*/
	float 	*acc_mu_loss 	= new float[number_sp];					/* Rate of gene loss, or reverse mutation					*/
	float 	*g_mu 			= new float[number_sp];					/* This is the combined forward/reverse rate for a strictly	*/
																	/* core and non-recombining set of regions of the genome	*/
																	/* In one context, it may be the core genome, in another	*/
																	/* a non-recombining marker locus.							*/
	float 	*a 				= new float[number_sp * 5];				/* A set of parameters for caluculating fitnesses			*/
	
	int tmp_int;
	float tmp_float;
	for(int i = 0; i <= number_sp - 1; i++)	{
		
		infilep >> tmp_int; 		sample_size[i] 	= tmp_int;									std::cout << sample_size[i] << " ";
		infilep >> tmp_float;		ne[i] 			= tmp_float;								std::cout << ne[i] << " ";
		infilep >> tmp_float;		sel_coef[i] 	= tmp_float;								std::cout << sel_coef[i] << " ";
		infilep >> tmp_float;		r[i] 			= tmp_float;								std::cout << r[i] << " ";
		infilep >> tmp_float;		gamma[i] 		= tmp_float;								std::cout << gamma[i] << " ";
		
		for(int j = 0; j <= number_sp - 1; j++)	{
			infilep >> tmp_int; 
			num_intr[i * number_sp + j] = tmp_int; 
			std::cout << num_intr[i * number_sp + j] << " ";
		}
	
		infilep >> tmp_float;		acc_mu_gain[i] 	= tmp_float;		acc_mu_gain[i] = acc_mu_gain[i]/2;	std::cout << acc_mu_gain[i] << " ";
		infilep >> tmp_float;		acc_mu_loss[i] 	= tmp_float;		acc_mu_loss[i] = acc_mu_loss[i]/2;	std::cout << acc_mu_loss[i] << " ";
		infilep >> tmp_float; 		g_mu[i] 		= tmp_float;		g_mu[i] = g_mu[i]/2;		std::cout << g_mu[i] << " ";
		
		for(int j = 0; j <= 5 - 1; j++)	{
			infilep >> tmp_float; 	
			a[i * 5 + j] = tmp_float; 
			std::cout << a[i * 5 + j] << " ";
		}
		std::cout << std::endl;
	}
	
	int hgt_or_rec;			infilep >> hgt_or_rec;					std::cout << hgt_or_rec << std::endl;		/* Indicator of whether r 		*/
																												/* corresponds to recomb		*/
																												/* or hgt						*/

	float alpha;			infilep >> alpha;						std::cout << alpha << std::endl;			/* Parameter associated with	*/
																												/* probability of displacement	*/

	float t_max;			infilep >> t_max;						std::cout << t_max << std::endl;			/* Make number of generations	*/
	int num_acc_chr;		infilep >> num_acc_chr;					std::cout << num_acc_chr << std::endl;		/* Number of accessory chromo-	*/
																												/* somes or genomic sections, 	*/
																												/* depending on context.		*/
	int num_core_chr;		infilep >> num_core_chr;				std::cout << num_core_chr << std::endl;		/* Number of core/marker chromo-*/
																												/* somes or genomic sections, 	*/
																												/* depending on context.		*/
	int num_acc_reg;		infilep >> num_acc_reg;					std::cout << num_acc_reg << std::endl;		/* Number of 15 gene or bp 		*/
																												/* regions per chr or section	*/
	int num_core_reg;		infilep >> num_core_reg;				std::cout << num_core_reg << std::endl;		/* Number of 15 gene or bp 		*/
																												/* regions per chr or section	*/
	
	int num_reg_aff_opt;	infilep >> num_reg_aff_opt;				std::cout << num_reg_aff_opt << std::endl;	/* Number of acc regions 		*/
																												/* affecting fitness			*/
	infilep >> tmp_int;
	int 	*opt_acc_genotype	= new int[num_acc_chr * num_acc_reg];											/* Optimal genotype within a 	*/
																												/* 15 gene/bp region			*/
	for(int j = 0; j <= num_acc_chr * num_acc_reg - 1; j++)	{
			if(j <= num_reg_aff_opt - 1)
				opt_acc_genotype[j] = tmp_int;
			else
				opt_acc_genotype[j] = 0;
			std::cout << opt_acc_genotype[j] << " ";
	}
	std::cout << std::endl;
	
	/* Parameters associated with how data is processed on GPU, see ReadMe																		*/
	int gpu_local_item_size;		infilep >> gpu_local_item_size;								std::cout << gpu_local_item_size << " ";
	int gpu_global_item_size;		infilep >> gpu_global_item_size;							std::cout << gpu_global_item_size << " ";
	int gpu_num_cores;				infilep >> gpu_num_cores;									std::cout << gpu_num_cores << " ";
	int graph_cycles_mult;			infilep >> graph_cycles_mult;								std::cout << graph_cycles_mult << " ";
	int block_size;					infilep >> block_size;										std::cout << block_size << std::endl;
	
	/* Create GPU kernels		*/
	cl_context context_rnd_uniform;
  	cl_command_queue command_queue_rnd_uniform;
  	cl_program program_rnd_uniform;
  	cl_kernel kernel_rnd_uniform;
	
	
	create_kernel_cl(&context_rnd_uniform, &command_queue_rnd_uniform, &program_rnd_uniform, &kernel_rnd_uniform, 
							CL_DEVICE_TYPE_GPU, "cl_files/mwc64x.cl", "rnd_uniform");
	
	cl_context context_net_gain_loss;
  	cl_command_queue command_queue_net_gain_loss;
  	cl_program program_net_gain_loss;
  	cl_kernel kernel_net_gain_loss;
	
	create_kernel_cl(&context_net_gain_loss, &command_queue_net_gain_loss, &program_net_gain_loss, &kernel_net_gain_loss, 
							CL_DEVICE_TYPE_GPU, "cl_files/calc_net_gain_loss.cl", "calc_net_gain_loss");						
	
	cl_context context_mut;
  	cl_command_queue command_queue_mut;
  	cl_program program_mut;
  	cl_kernel kernel_mut;
	
	create_kernel_cl(&context_mut, &command_queue_mut, &program_mut, &kernel_mut, 
							CL_DEVICE_TYPE_GPU, "cl_files/calc_mut.cl", "calc_mut");
					
	cl_context context_calc_k;
  	cl_command_queue command_queue_calc_k;
  	cl_program program_calc_k;
  	cl_kernel kernel_calc_k;
							
	create_kernel_cl(&context_calc_k, &command_queue_calc_k, &program_calc_k, &kernel_calc_k, 
							CL_DEVICE_TYPE_GPU, "cl_files/calc_k.cl", "calc_k");
						
	cl_context context_time_to_anc;
  	cl_command_queue command_queue_time_to_anc;
  	cl_program program_time_to_anc;
  	cl_kernel kernel_time_to_anc;
							
	create_kernel_cl(&context_time_to_anc, &command_queue_time_to_anc, &program_time_to_anc, &kernel_time_to_anc, 
							CL_DEVICE_TYPE_GPU, "cl_files/time_to_anc.cl", "time_to_anc");
							
	cl_context context_calc_acc_genotype;
  	cl_command_queue command_queue_calc_acc_genotype;
  	cl_program program_calc_acc_genotype;
  	cl_kernel kernel_calc_acc_genotype;
  	
	create_kernel_cl(&context_calc_acc_genotype, &command_queue_calc_acc_genotype, &program_calc_acc_genotype, &kernel_calc_acc_genotype, 
							CL_DEVICE_TYPE_GPU, "cl_files/calc_acc_geno.cl", "calc_acc_genotype");

	t = time(NULL);
	
	/* Begin replicate simulations of ancestral process */
	int rep = 0;
	while(rep <= number_reps - 1)		{																	
		std::cout << "Rep: " << rep << std::endl;
		
		/* Set up pointers to data objects.  These objects are taken as arguments in the gpu_graph() function. */
		int *sp_ID;
		int *desc1;
		int *desc2;
		int *ancestor1;
		int *ancestor2;
		int *intr_ind;
		
		int **acc_genotype;
		
		int **core_genotype_1;
		int **core_genotype_2;
		
		int graph_size;
	
		/* Generate ancestral graph for a replicate */
		graph_size = gpu_graph(number_sp, sample_size, sel_coef, r, num_intr, t_max, ne, gamma,
				acc_mu_gain, acc_mu_loss, num_acc_chr, num_acc_reg, g_mu, num_core_chr, num_core_reg,
				gpu_local_item_size, gpu_global_item_size, gpu_num_cores,
				graph_cycles_mult, block_size,
				a, opt_acc_genotype, hgt_or_rec, alpha,
				sp_ID, desc1, desc2, ancestor1, ancestor2, intr_ind,
				acc_genotype, core_genotype_1, core_genotype_2,
				
				context_rnd_uniform, command_queue_rnd_uniform,
  				program_rnd_uniform, kernel_rnd_uniform,
  				
  				context_net_gain_loss, command_queue_net_gain_loss,
  				program_net_gain_loss, kernel_net_gain_loss,
  				
  				context_mut, command_queue_mut,
  				program_mut, kernel_mut,
  				
  				context_calc_k, command_queue_calc_k,
  				program_calc_k, kernel_calc_k,
  				
  				context_time_to_anc, command_queue_time_to_anc,
  				program_time_to_anc, kernel_time_to_anc,
  				
  				context_calc_acc_genotype, command_queue_calc_acc_genotype,
  				program_calc_acc_genotype, kernel_calc_acc_genotype
				
				);
        
        std::cout << "Exited gpu_graph" << std::endl;
        
	
	/* Data ouput: Data.out are acc genotypes; Geno.out are core/marker genotypes															*/
	if(graph_size > 0)	{

        FILE *file_ptr;
		char filename[100];
		sprintf(filename,"Data.out");
		file_ptr = fopen(filename,"a");
		if(file_ptr == NULL)	{
			printf("Cannot open file.\n");
			exit(8);
		}
		
		int indx = 0;
		for(int i = 0; i <= number_sp - 1; i++)	{
        	 for(int j = 0; j <= sample_size[i] - 1; j++) {
				fprintf(file_ptr,"[");
				for(int chr = 0; chr <= num_acc_chr - 1; chr++)	{
        		for(int k = 0; k <= num_acc_reg - 1; k++)	{
        			if(chr == num_acc_chr - 1 && k == num_acc_reg - 1)
			        	fprintf(file_ptr,"%d]\n",acc_genotype[indx][ chr * num_acc_reg + k]);
			        else
			        	fprintf(file_ptr,"%d,",acc_genotype[indx][ chr * num_acc_reg + k]);
		        }}
		        delete[] acc_genotype[indx];
		        indx = indx + 1;
		     }
		}
		fclose(file_ptr);
		
		sprintf(filename,"Geno.out");
		file_ptr = fopen(filename,"a");
		if(file_ptr == NULL)	{
			printf("Cannot open file.\n");
			exit(8);
		}
		
		indx = 0;
		for(int i = 0; i <= number_sp - 1; i++)	{
        	 for(int j = 0; j <= sample_size[i] - 1; j++) {
				fprintf(file_ptr,"[");
				for(int chr = 0; chr <= num_core_chr - 1; chr++)	{
        		for(int k = 0; k <= num_core_reg - 1; k++)	{
		        	if(chr == num_core_chr - 1 && k == num_core_reg - 1)
			        	fprintf(file_ptr,"%d]\n",core_genotype_1[indx][ chr * num_core_reg + k]);
			        else
			        	fprintf(file_ptr,"%d,",core_genotype_1[indx][ chr * num_core_reg + k]);
		        }}
		        delete[] core_genotype_1[indx];
		        delete[] core_genotype_2[indx];
		        indx = indx + 1;
		     }
		}
		fclose(file_ptr);
	}
	
        delete[] sp_ID;
        delete[] desc1;
		delete[] desc2;
		delete[] ancestor1;
		delete[] ancestor2;
		delete[] intr_ind;
		
		delete[] acc_genotype;
		delete[] core_genotype_1;
		delete[] core_genotype_2;
		
		if(graph_size > 0) rep = rep + 1;
	}
	
	t = time(NULL) - t;
	printf("Total time: %ld\n",t);
	
return 0;
}	

	
