/* Sets up a call to the calc_acc_geno.cl GPU kernel */

#include <stdlib.h>
#include <stdio.h>
#include<new>
#include<vector>
#include<time.h>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

#include"header.h"

void calc_acc_genotype_cl(int block_size, int block_start, int block_stop, int number_sp,
				int *sp_ID, int *acc_genotype, int *acc_genotype_updated, 
				int *ancestor1, int *ancestor2, int *intr_ind,
				int num_acc_reg, int *num_intr, int max_num_intr,
				int *k_1_acc, int *k_2_acc, int *mut_1_acc, int *mut_2_acc,
				int *k_1_core, int *k_2_core, int *mut_1_core, int *mut_2_core, int *genotype_1, int *genotype_2, int num_core_reg,
				int num_mut_1_acc, int num_mut_2_acc, int *sum_k_1_acc, int *sum_k_2_acc,
				int num_mut_1_core, int num_mut_2_core, int *sum_k_1_core, int *sum_k_2_core,
				cl_context context,cl_command_queue command_queue,cl_program program,cl_kernel kernel,
				int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores,
                int graph_cycles_mult,
                float *a, int *opt_genotype, float alpha,
                float *rand_uniform_1, int *node_event, int hgt_or_rec, float *rand_uniform_2, int num_rec) {

  printf("Calculating phenotypes and genotypes\n");

  cl_int ret;
		
  /* Shared parameters across parallel processes 	*/
  size_t global_item_size, local_item_size;
  size_t k_buffer_size;
  size_t rand_buffer_size;
  global_item_size = gpu_global_item_size; 
  local_item_size = gpu_local_item_size;  
  
  k_buffer_size = (block_size - block_size % local_item_size + local_item_size);
  rand_buffer_size = (block_size - block_size % gpu_num_cores + global_item_size);
  		
	int *gid_to_node_translator;
	gid_to_node_translator = new int[global_item_size];
	
	int *tmp_acc_1;
	int *tmp_acc_2;
	
	tmp_acc_1 = new int[gpu_num_cores*num_acc_reg];
	tmp_acc_2 = new int[gpu_num_cores*num_acc_reg];
	
	for(int i = 0; i <= global_item_size - 1; i++)	gid_to_node_translator[i] = block_size - i - 1;
	
		/* Generate input buffers and set kernel arguments. */		
  		cl_mem acc_genotype_buffer;
  		cl_mem ancestor1_buffer;
  		cl_mem ancestor2_buffer;
  		cl_mem intr_ind_buffer;
  		cl_mem acc_genotype_updated_buffer;
  		cl_mem k_1_acc_buffer;
  		cl_mem k_2_acc_buffer;
  		cl_mem k_1_core_buffer;
  		cl_mem k_2_core_buffer;
  		cl_mem mut_1_acc_buffer;
  		cl_mem mut_2_acc_buffer;
  		cl_mem mut_1_core_buffer;
  		cl_mem mut_2_core_buffer;
  		cl_mem genotype_1_buffer;
  		cl_mem genotype_2_buffer;
  		cl_mem gid_to_node_translator_buffer;
  		cl_mem sum_k_1_acc_buffer;
  		cl_mem sum_k_2_acc_buffer;
  		cl_mem sum_k_1_core_buffer;
  		cl_mem sum_k_2_core_buffer;
  		cl_mem num_intr_buffer;
  		cl_mem sp_ID_buffer;
  		cl_mem a_buffer;
  		cl_mem rand_uniform_1_buffer;
  		cl_mem opt_genotype_buffer;
  		cl_mem tmp_acc_1_buffer;
  		cl_mem tmp_acc_2_buffer;
  		cl_mem node_event_buffer;
  		cl_mem rand_uniform_2_buffer;

  		acc_genotype_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size*num_acc_reg, acc_genotype, &ret); 		if(ret != CL_SUCCESS) printf("Buffer problem 1\n");
  		ancestor1_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, ancestor1, &ret); 							if(ret != CL_SUCCESS) printf("Buffer problem 2\n");
  		ancestor2_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, ancestor2, &ret); 							if(ret != CL_SUCCESS) printf("Buffer problem 3\n");
  		intr_ind_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size*max_num_intr, intr_ind, &ret); 				if(ret != CL_SUCCESS && max_num_intr > 0) printf("Buffer problem 4\n");
  		acc_genotype_updated_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, acc_genotype_updated, &ret); 	if(ret != CL_SUCCESS) printf("Buffer problem 5\n");
  		k_1_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*k_buffer_size, k_1_acc, &ret);							if(ret != CL_SUCCESS) printf("Buffer problem 6\n");
  		k_2_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*k_buffer_size, k_2_acc, &ret); 							if(ret != CL_SUCCESS) printf("Buffer problem 7\n");
  		k_1_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*k_buffer_size, k_1_core, &ret);							if(ret != CL_SUCCESS) printf("Buffer problem 8\n");
  		k_2_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*k_buffer_size, k_2_core, &ret); 						if(ret != CL_SUCCESS) printf("Buffer problem 9\n");
  		mut_1_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*num_mut_1_acc, mut_1_acc, &ret);						if(ret != CL_SUCCESS) printf("Buffer problem 10\n");
  		mut_2_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*num_mut_2_acc, mut_2_acc, &ret); 						if(ret != CL_SUCCESS && num_mut_2_acc > 0) if(ret != CL_SUCCESS) printf("Buffer problem 11\n");
  		mut_1_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*num_mut_1_core, mut_1_core, &ret);					if(ret != CL_SUCCESS) printf("Buffer problem 12\n");
  		mut_2_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*num_mut_2_core, mut_2_core, &ret); 					if(ret != CL_SUCCESS && num_mut_2_core > 0) if(ret != CL_SUCCESS) printf("Buffer problem 13\n");
  		genotype_1_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size*num_core_reg, genotype_1, &ret);			if(ret != CL_SUCCESS) printf("Buffer problem 14\n");
  		genotype_2_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size*num_core_reg, genotype_2, &ret); 			if(ret != CL_SUCCESS) printf("Buffer problem 15\n");
		gid_to_node_translator_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*global_item_size, 
  															gid_to_node_translator, &ret); 																		if(ret != CL_SUCCESS) printf("Buffer problem 16\n");
		
		sum_k_1_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sum_k_1_acc, &ret);						if(ret != CL_SUCCESS) printf("Buffer problem 17\n");
		sum_k_2_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sum_k_2_acc, &ret);
		sum_k_1_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sum_k_1_core, &ret);					if(ret != CL_SUCCESS) printf("Buffer problem 18\n");
		sum_k_2_core_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sum_k_2_core, &ret);					if(ret != CL_SUCCESS) printf("Buffer problem 19\n");
		
		num_intr_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*number_sp*number_sp, num_intr, &ret);					if(ret != CL_SUCCESS) printf("Buffer problem 20\n");
		sp_ID_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sp_ID, &ret);									if(ret != CL_SUCCESS) printf("Buffer problem 21\n");					
		a_buffer = 	clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*number_sp*5, a, &ret);										if(ret != CL_SUCCESS) printf("Buffer problem 22\n");
		opt_genotype_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*num_acc_reg, opt_genotype, &ret);					if(ret != CL_SUCCESS) printf("Buffer problem 23\n");
		
		rand_uniform_1_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*rand_buffer_size, rand_uniform_1, &ret);			if(ret != CL_SUCCESS) printf("Buffer problem 24\n");
		tmp_acc_1_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*gpu_num_cores*num_acc_reg, tmp_acc_1, &ret); 						if(ret != CL_SUCCESS) printf("Buffer problem 25\n");
		tmp_acc_2_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*gpu_num_cores*num_acc_reg, tmp_acc_2, &ret); 						if(ret != CL_SUCCESS) printf("Buffer problem 26\n");
		node_event_buffer = clCreateBuffer(context, CL_MEM_READ_WRITE|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, node_event, &ret); 						if(ret != CL_SUCCESS) printf("Buffer problem 27\n");
		
		rand_uniform_2_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*rand_buffer_size, rand_uniform_2, &ret);	if(ret != CL_SUCCESS) printf("Buffer problem 28\n");
		
printf("Size of buffer to GPU: %lu\n",	sizeof(cl_int)*block_size*num_acc_reg 
										 + 2 * sizeof(cl_int)*block_size 
										 + sizeof(cl_int)*block_size*max_num_intr 
										 + sizeof(cl_int)*block_size 
										 + 4 * sizeof(cl_int)*k_buffer_size
										 + sizeof(cl_int)*num_mut_1_acc 
										 + sizeof(cl_int)*num_mut_2_acc
										 + sizeof(cl_int)*num_mut_1_core 
										 + sizeof(cl_int)*num_mut_2_core
										 + 2 * sizeof(cl_int)*block_size*num_core_reg 
										 + sizeof(cl_int)*global_item_size
										 + 4 * sizeof(cl_int)*block_size 
										 + sizeof(cl_int)*number_sp*number_sp
										 + sizeof(cl_int)*block_size
										 + sizeof(cl_float)*number_sp*5
										 + sizeof(cl_int)*num_acc_reg
										 + 2*sizeof(cl_float)*rand_buffer_size
										 + sizeof(cl_int)*gpu_num_cores*num_acc_reg * 2
										 + sizeof(cl_int)*block_size);
printf("Block size: %d\n",block_size);		
			
		int num_opt_sites = 0;
        for (int reg = 0; reg <= num_acc_reg - 1; reg++)	{
	    	for (int i = 1; i <= 15; i++) 	{
				if((1 << i) & opt_genotype[reg])
					num_opt_sites = num_opt_sites + 1;
			}
		}
  		
  		/* Set Kernel Arguments for all buffers */
  		ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), &acc_genotype_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 0\n");
  		ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), &ancestor1_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 1\n");
  		ret = clSetKernelArg(kernel, 2, sizeof(cl_mem), &ancestor2_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 2\n");
  		ret = clSetKernelArg(kernel, 3, sizeof(cl_mem), &intr_ind_buffer); 					if(ret != CL_SUCCESS) printf("Arg problem 3\n");
  		ret = clSetKernelArg(kernel, 4, sizeof(cl_mem), &acc_genotype_updated_buffer); 		if(ret != CL_SUCCESS) printf("Arg problem 4\n");
  		ret = clSetKernelArg(kernel, 5, sizeof(cl_mem), &gid_to_node_translator_buffer);	if(ret != CL_SUCCESS) printf("Arg problem 5\n");
  		ret = clSetKernelArg(kernel, 6, sizeof(cl_int), &global_item_size); 				if(ret != CL_SUCCESS) printf("Arg problem 6\n");
  		ret = clSetKernelArg(kernel, 7, sizeof(cl_mem), &k_1_acc_buffer); 					if(ret != CL_SUCCESS) printf("Arg problem 7\n");
  		ret = clSetKernelArg(kernel, 8, sizeof(cl_mem), &k_2_acc_buffer); 					if(ret != CL_SUCCESS) printf("Arg problem 8\n");
  		ret = clSetKernelArg(kernel, 9, sizeof(cl_mem), &k_1_core_buffer); 					if(ret != CL_SUCCESS) printf("Arg problem 9\n");
  		ret = clSetKernelArg(kernel, 10, sizeof(cl_mem), &k_2_core_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 10\n");
		ret = clSetKernelArg(kernel, 11, sizeof(cl_mem), &mut_1_acc_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 11\n");
  		ret = clSetKernelArg(kernel, 12, sizeof(cl_mem), &mut_2_acc_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 12\n");
  		ret = clSetKernelArg(kernel, 13, sizeof(cl_mem), &mut_1_core_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 13\n");
  		ret = clSetKernelArg(kernel, 14, sizeof(cl_mem), &mut_2_core_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 14\n");
		ret = clSetKernelArg(kernel, 15, sizeof(cl_mem), &genotype_1_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 15\n");
  		ret = clSetKernelArg(kernel, 16, sizeof(cl_mem), &genotype_2_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 16\n");
  		ret = clSetKernelArg(kernel, 17, sizeof(cl_mem), &a_buffer); 						if(ret != CL_SUCCESS) printf("Arg problem 17\n");
  		ret = clSetKernelArg(kernel, 18, sizeof(cl_mem), &sum_k_1_acc_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 18\n");
  		ret = clSetKernelArg(kernel, 19, sizeof(cl_mem), &sum_k_2_acc_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 19\n");
  		ret = clSetKernelArg(kernel, 20, sizeof(cl_mem), &sum_k_1_core_buffer); 			if(ret != CL_SUCCESS) printf("Arg problem 20\n");
  		ret = clSetKernelArg(kernel, 21, sizeof(cl_mem), &sum_k_2_core_buffer); 			if(ret != CL_SUCCESS) printf("Arg problem 21\n");
  		ret = clSetKernelArg(kernel, 22, sizeof(cl_int), &num_acc_reg); 					if(ret != CL_SUCCESS) printf("Arg problem 22\n");
  		ret = clSetKernelArg(kernel, 23, sizeof(cl_int), &num_core_reg); 					if(ret != CL_SUCCESS) printf("Arg problem 23\n");
		ret = clSetKernelArg(kernel, 24, sizeof(cl_int), &max_num_intr); 					if(ret != CL_SUCCESS) printf("Arg problem 24\n");
		ret = clSetKernelArg(kernel, 25, sizeof(cl_mem), &num_intr_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 25\n");
		ret = clSetKernelArg(kernel, 26, sizeof(cl_int), &number_sp); 						if(ret != CL_SUCCESS) printf("Arg problem 26\n");
		ret = clSetKernelArg(kernel, 27, sizeof(cl_mem), &sp_ID_buffer); 					if(ret != CL_SUCCESS) printf("Arg problem 27\n");
		ret = clSetKernelArg(kernel, 28, sizeof(cl_mem), &opt_genotype_buffer); 			if(ret != CL_SUCCESS) printf("Arg problem 28\n");
		ret = clSetKernelArg(kernel, 29, sizeof(cl_int), &num_opt_sites); 					if(ret != CL_SUCCESS) printf("Arg problem 29\n");
		ret = clSetKernelArg(kernel, 30, sizeof(cl_float), &alpha); 						if(ret != CL_SUCCESS) printf("Arg problem 30\n");
		ret = clSetKernelArg(kernel, 31, sizeof(cl_mem), &rand_uniform_1_buffer); 			if(ret != CL_SUCCESS) printf("Arg problem 31\n");
		ret = clSetKernelArg(kernel, 32, sizeof(cl_mem), &tmp_acc_1_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 32\n");
		ret = clSetKernelArg(kernel, 33, sizeof(cl_mem), &tmp_acc_2_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 33\n");
		ret = clSetKernelArg(kernel, 34, sizeof(cl_mem), &node_event_buffer); 				if(ret != CL_SUCCESS) printf("Arg problem 34\n");
		ret = clSetKernelArg(kernel, 35, sizeof(cl_int), &hgt_or_rec); 						if(ret != CL_SUCCESS) printf("Arg problem 35\n");
		ret = clSetKernelArg(kernel, 36, sizeof(cl_mem), &rand_uniform_2_buffer); 			if(ret != CL_SUCCESS) printf("Arg problem 36\n");
		
	int count = 0;
	int check = 0;	
    int check_value = (int) block_size/global_item_size * graph_cycles_mult;
	int num_check = 0;
	
	while(1)	{
		check++;		
					
  		/* Get results	*/
  		ret = clEnqueueNDRangeKernel(command_queue, kernel, 1, NULL, &global_item_size, &local_item_size, 0, NULL, NULL);
  		
  		/* Check to see if graph has been calculated, but only after check_value loops	*/
		if(check > check_value)	{
			num_check++;

			ret = clEnqueueReadBuffer(command_queue, gid_to_node_translator_buffer, CL_TRUE, 0, sizeof(int)*global_item_size, 
											gid_to_node_translator, 0, NULL, NULL);						//printf("%d\n",ret);	

			count = 0;
			for(int i = 0; i <= global_item_size - 1; i++) if(gid_to_node_translator[i] >= 0)	count++;
            
            printf("Calc x stats, Num positive nodes in cycle: %d, cycle: %d \n",count,check);
            
            if(count < 1)
                break;
		}
	}
		
		/* Read back acc_genotype */
		ret = clEnqueueReadBuffer(command_queue, acc_genotype_buffer, CL_TRUE, 0, sizeof(int)*block_size*num_acc_reg, acc_genotype, 0, NULL, NULL);						printf("%d\n",ret);	
		ret = clEnqueueReadBuffer(command_queue, acc_genotype_updated_buffer, CL_TRUE, 0, sizeof(int)*block_size, acc_genotype_updated, 0, NULL, NULL);
		ret = clEnqueueReadBuffer(command_queue, genotype_1_buffer, CL_TRUE, 0, sizeof(int)*block_size*num_core_reg, genotype_1, 0, NULL, NULL);						//printf("%d\n",ret);
		ret = clEnqueueReadBuffer(command_queue, genotype_2_buffer, CL_TRUE, 0, sizeof(int)*block_size*num_core_reg, genotype_2, 0, NULL, NULL);						//printf("%d\n",ret);		
		
  		/* Release Buffers */
		ret = clReleaseMemObject(acc_genotype_buffer);
		ret = clReleaseMemObject(ancestor1_buffer);
		ret = clReleaseMemObject(ancestor2_buffer);
		ret = clReleaseMemObject(intr_ind_buffer);
		ret = clReleaseMemObject(acc_genotype_updated_buffer);
		ret = clReleaseMemObject(gid_to_node_translator_buffer);
		ret = clReleaseMemObject(k_1_acc_buffer);
		ret = clReleaseMemObject(k_2_acc_buffer);
		ret = clReleaseMemObject(k_1_core_buffer);
		ret = clReleaseMemObject(k_2_core_buffer);
        ret = clReleaseMemObject(mut_1_acc_buffer);
		ret = clReleaseMemObject(mut_2_acc_buffer);
		ret = clReleaseMemObject(mut_1_core_buffer);
		ret = clReleaseMemObject(mut_2_core_buffer);
		ret = clReleaseMemObject(genotype_1_buffer);
		ret = clReleaseMemObject(genotype_2_buffer);
		ret = clReleaseMemObject(sum_k_1_acc_buffer);
		ret = clReleaseMemObject(sum_k_2_acc_buffer);
		ret = clReleaseMemObject(sum_k_1_core_buffer);
		ret = clReleaseMemObject(sum_k_2_core_buffer);
		ret = clReleaseMemObject(sp_ID_buffer);
		ret = clReleaseMemObject(opt_genotype_buffer);
		ret = clReleaseMemObject(rand_uniform_1_buffer);
		ret = clReleaseMemObject(num_intr_buffer);
		ret = clReleaseMemObject(a_buffer);	
		ret = clReleaseMemObject(tmp_acc_1_buffer);
		ret = clReleaseMemObject(tmp_acc_2_buffer);
		ret = clReleaseMemObject(node_event_buffer);
		ret = clReleaseMemObject(rand_uniform_2_buffer);
		
		delete[] tmp_acc_1;
		delete[] tmp_acc_2;
		
	delete[] gid_to_node_translator;
	
	printf("Exit Calculating phenotypes and genotypes\n");
	return;
}
