/* Sets up a call to the calc_net_gain_loss.cl GPU kernel */

#include <stdlib.h>
#include <stdio.h>
#include<new>
#include<vector>
#include<time.h>
#include<iostream>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

#include"header.h"

void calc_net_gain_loss_cl(int block_size, int *sum_k_acc, int sum_k_acc_tot, int *k_acc, int number_sp, int *sp_ID, 
							int *acc_mut_lst, 
							int min, int max, 
							float *mu_gain, float *mu_loss, float *rand_num_1, float *rand_num_2,
							cl_context context, cl_command_queue command_queue, cl_program program, cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores) {
  
  printf("Calculating gain loss\n");
  
  cl_int ret;
  		
  /* Shared parameters across parallel processes 	*/
  size_t global_item_size, local_item_size, tot_rand_num;
  local_item_size = 1;
  global_item_size = (block_size /*- block_size % local_item_size + local_item_size*/);
  
  tot_rand_num = (sum_k_acc_tot - sum_k_acc_tot % local_item_size + local_item_size); 
    
  /* Generate input and/or output buffers and set kernel arguments */		
  cl_mem sum_k_acc_buffer;
  cl_mem k_acc_buffer;
  cl_mem sp_ID_buffer;
  cl_mem acc_mut_lst_buffer;
  cl_mem mu_gain_buffer;
  cl_mem mu_loss_buffer;
  cl_mem rand_num_1_buffer;
  cl_mem rand_num_2_buffer;
  
  sum_k_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sum_k_acc, &ret);				//std::cout << ret << " " << CL_SUCCESS << std::endl;
  k_acc_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, k_acc, &ret);						//std::cout << ret << std::endl;
  sp_ID_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*block_size, sp_ID, &ret);						//std::cout << ret << std::endl;
  acc_mut_lst_buffer = clCreateBuffer(context, CL_MEM_WRITE_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_int)*sum_k_acc_tot, acc_mut_lst, &ret);		//std::cout << ret << std::endl;
  mu_gain_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*number_sp, mu_gain, &ret);					//std::cout << ret << std::endl;
  mu_loss_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*number_sp, mu_loss, &ret);					//std::cout << ret << std::endl;
  rand_num_1_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*tot_rand_num, rand_num_1, &ret);			//std::cout << ret << std::endl;
  rand_num_2_buffer = clCreateBuffer(context, CL_MEM_READ_ONLY|CL_MEM_COPY_HOST_PTR, sizeof(cl_float)*tot_rand_num, rand_num_2, &ret);			//std::cout << ret << std::endl;
  
  /* Set Kernel Arguments */  
  ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), &sum_k_acc_buffer); 							//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), &k_acc_buffer); 								//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 2, sizeof(cl_mem), &sp_ID_buffer); 								//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 3, sizeof(cl_mem), &acc_mut_lst_buffer); 						//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 4, sizeof(cl_int), &min); 										//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 5, sizeof(cl_int), &max); 										//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 6, sizeof(cl_mem), &mu_gain_buffer); 							//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 7, sizeof(cl_mem), &mu_loss_buffer); 							//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 8, sizeof(cl_mem), &rand_num_1_buffer); 							//std::cout << ret << std::endl;
  ret = clSetKernelArg(kernel, 9, sizeof(cl_mem), &rand_num_2_buffer); 							//std::cout << ret << std::endl;
  
  /* Get results	*/	
  ret = clEnqueueNDRangeKernel(command_queue, kernel, 1, NULL, &global_item_size, &local_item_size, 0, NULL, NULL);						//std::cout << ret << std::endl;  
  ret = clEnqueueReadBuffer(command_queue, acc_mut_lst_buffer, CL_TRUE, 0, sizeof(int)*sum_k_acc_tot, acc_mut_lst, 0, NULL, NULL);		std::cout << ret << std::endl;
  
  ret = clReleaseMemObject(sum_k_acc_buffer);
  ret = clReleaseMemObject(k_acc_buffer);
  ret = clReleaseMemObject(sp_ID_buffer);
  ret = clReleaseMemObject(acc_mut_lst_buffer);
  ret = clReleaseMemObject(rand_num_1_buffer);
  ret = clReleaseMemObject(rand_num_2_buffer);
  ret = clReleaseMemObject(mu_gain_buffer);
  ret = clReleaseMemObject(mu_loss_buffer);
  
  printf("Exit Calculating gain loss\n");
  return;
}