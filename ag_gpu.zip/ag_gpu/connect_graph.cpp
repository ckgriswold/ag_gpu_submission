#include<new>
#include<math.h>
#include<iostream>
#include<vector>

#include"header.h"
#include"Mersenne.h"
#include"RanDev.h"

void connect_graph(float *prelim_graph_events, float *prelim_graph_sp, float *prelim_graph_node_in_graph, 
					int graph_size, int number_sp, int num_acc_chr, int num_acc_reg, int *num_intr, 
						int *sp_ID, int *desc1, int *desc2, int *ancestor1, int *ancestor2,
							int *intr_ind, int *acc_genotype_updated, int **acc_genotype, float *rand_num, int max_num_intr,
								int *node_event) {
	
	std::vector<int> *available_nodes = new std::vector<int>[number_sp];
	int rand_indx = 0;
	
	std::vector<int> *tmp_available_nodes = new std::vector<int>[number_sp];;
	int type_3_indicator = 0;
	
	int i = 0;
	while(i <= graph_size - 1) {
		
		if(type_3_indicator == 1 && prelim_graph_events[i] != 3.0)	{							//std::cout << "type_3 if: in" << std::endl;
			type_3_indicator = 0;
			
			for(int sp = 0; sp <= number_sp - 1; sp++)	{
				for(int j = 0; j <= tmp_available_nodes[sp].size() - 1; j++)
					available_nodes[sp].push_back(tmp_available_nodes[sp].at(j));
			
				tmp_available_nodes[sp].clear();
			}
																								//std::cout << "type_3 if: out" << std::endl;
		}
		
		if(prelim_graph_events[i] == 0.0)	{													//std::cout << "event 0: in" << std::endl;
				/* Initialization */
				
				sp_ID[i] = int(prelim_graph_sp[i]);
				desc1[i] = -1;
				desc2[i] = -1;
				ancestor1[i] = -1;
				ancestor2[i] = -1;
				
				node_event[i] = 0;
				
				for(int ind = 0; ind <= max_num_intr - 1; ind++)	{
					intr_ind[i * max_num_intr + ind] = -1;
				}
				
				acc_genotype_updated[i] = 0;
				
				int sp = sp_ID[i];
				available_nodes[sp].push_back(i);
				i = i + 1;
																								//std::cout << "event 0: out" << std::endl;
		}
		else if(prelim_graph_events[i] == 3.0)	{												//std::cout << "event 3: in" << std::endl;
				/* Graph Slice	*/
				
				int sp = -1;
				for(int j = 0; j <= number_sp - 1; j++) {
					if(available_nodes[j].size() > 0) {
						sp = j;
						break;
					}
				} 
				
				sp_ID[i] = sp;
				
				if(sp == -1) {
					std::cout << "Error getting species ID during graph slice." << std::endl;
					exit(8);
				}
				
				int indx = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
				desc1[i] = available_nodes[sp].at(indx);
					ancestor1[desc1[i]] = i;
					available_nodes[sp].erase(available_nodes[sp].begin() + indx);
				
				desc2[i] = -1;
				ancestor1[i] = -1;
				ancestor2[i] = -1;
				
				node_event[desc1[i]] = 3;
				
				for(int ind = 0; ind <= max_num_intr - 1; ind++)	{
					intr_ind[i * max_num_intr + ind] = -1;
				}
				
				acc_genotype_updated[i] = 0;
				
				tmp_available_nodes[sp].push_back(i);
				i = i + 1;		
				
				type_3_indicator = 1;
																								//std::cout << "event 3: out" << std::endl;
		}
		else if(prelim_graph_events[i] == 1.0)	{												//std::cout << "event 1: in" << std::endl;
				/* Coalescent	*/
				
				sp_ID[i] = int(prelim_graph_sp[i]);
				int sp = sp_ID[i];
				
				/* Choose first descendant and link to ancestor */
				int indx = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
				desc1[i] = available_nodes[sp].at(indx);
					ancestor1[desc1[i]] = i;
					available_nodes[sp].erase(available_nodes[sp].begin() + indx);
				
				/* Choose second descendant	and link to ancestor */
				indx = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);		rand_indx = rand_indx + 1;
				desc2[i] = available_nodes[sp].at(indx);
					ancestor1[desc2[i]] = i;
					available_nodes[sp].erase(available_nodes[sp].begin() + indx);

				ancestor1[i] = -1;
				ancestor2[i] = -1;
				
				node_event[desc1[i]] = 1;
				node_event[desc2[i]] = 1;
				
				for(int ind = 0; ind <= max_num_intr - 1; ind++)	{
					intr_ind[i * max_num_intr + ind] = -1;
				}
				
				acc_genotype_updated[i] = 0;
				
				available_nodes[sp].push_back(i);
				i = i + 1;
																								//std::cout << "event 1: out" << std::endl;
		}		
		else if(prelim_graph_events[i] == 2.0)	{												//std::cout << "event 2: in" << std::endl;
				/* Selection 	*/
				
				sp_ID[i] = int(prelim_graph_sp[i]);
				sp_ID[i + 1] = int(prelim_graph_sp[i + 1]);
				int sp = sp_ID[i];
				
				/* Choose node that descends from competing nodes	*/
				int indx = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
					ancestor1[available_nodes[sp].at(indx)] = i;
					ancestor2[available_nodes[sp].at(indx)] = i + 1;
					
					node_event[available_nodes[sp].at(indx)] = 2;
				
				/* Link first competing node to its descendant */
				desc1[i] = available_nodes[sp].at(indx);
				desc2[i] = -1;
				
				/* Link second competing node to its descendant */
				desc1[i + 1] = available_nodes[sp].at(indx);
				
				available_nodes[sp].erase(available_nodes[sp].begin() + indx);	/* Delete descendant node */
				
				/* Is second node from outside of graph?  If not connect desc2 to graph. */
				if(prelim_graph_node_in_graph[i + 1] == 1.0)	{
					int indx2 = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
					desc2[i + 1] = available_nodes[sp].at(indx2);
					
					ancestor1[available_nodes[sp].at(indx2)] = i + 1;
					node_event[available_nodes[sp].at(indx2)] = 1;
					
					available_nodes[sp].erase(available_nodes[sp].begin() + indx2);	/* Delete descendant node */
				}
				else	{
					desc2[i + 1] = -1;
				}
				
				/* Initialize ancestors of competing nodes	*/
				ancestor1[i] = -1;
				ancestor2[i] = -1;
				
				acc_genotype_updated[i] = 0;
				
				ancestor1[i + 1] = -1;
				ancestor2[i + 1] = -1;
				
				acc_genotype_updated[i + 1] = 0;
				
				/* Link competing nodes to their interacting node	*/
				int max_num_intr_sp = 0; for(int int_sp = 0; int_sp <= number_sp - 1; int_sp++) max_num_intr_sp = max_num_intr_sp + 
																									num_intr[sp * number_sp + int_sp];
				for(int ind = 0; ind <= max_num_intr - 1; ind++)	{
					if(ind <= max_num_intr_sp - 1)	{
						intr_ind[i * max_num_intr + ind] = i + 2 + ind;
						intr_ind[(i + 1) * max_num_intr + ind] = i + 2 + ind;
					}
					else	{
						intr_ind[i * max_num_intr + ind] = -1;
						intr_ind[(i + 1) * max_num_intr + ind] = -1;
					}
				}
				
				/* Initialize interacting node */
				for(int ind = 0; ind <= max_num_intr_sp - 1; ind++)	{
					int intr_sp = int(prelim_graph_sp[i + 2 + ind]);
					/* Is interacting node from outside of graph?  If not connect desc1 to graph. */
					if(prelim_graph_node_in_graph[i + 2 + ind] == 1.0)	{
						int indx3 = RandomUniformInt(rand_num[rand_indx],0,available_nodes[intr_sp].size() - 1);	rand_indx = rand_indx + 1;
						desc1[i + 2 + ind] = available_nodes[intr_sp].at(indx3);
					
						ancestor1[available_nodes[intr_sp].at(indx3)] = i + 2 + ind;
						node_event[available_nodes[sp].at(indx3)] = 1;
						
						available_nodes[intr_sp].erase(available_nodes[intr_sp].begin() + indx3);	/* Delete descendant node */
						
						sp_ID[i + 2 + ind] = intr_sp;
						desc2[i + 2 + ind] = -1;
						ancestor1[i + 2 + ind] = -1;
						ancestor2[i + 2 + ind] = -1;
					}
					else	{

						sp_ID[i + 2 + ind] = intr_sp;
						desc1[i + 2 + ind] = -1;
						desc2[i + 2 + ind] = -1;
						ancestor1[i + 2 + ind] = -1;
						ancestor2[i + 2 + ind] = -1;
					}
					
					for(int ind2 = 0; ind2 <= max_num_intr - 1; ind2++)	{
						intr_ind[(i + 2 + ind) * max_num_intr + ind2] = -1;
					}
					
					acc_genotype_updated[i + 2 + ind] = 0;
					
				}
				
				available_nodes[sp].push_back(i);	/* Add first competing node */
				i = i + 1;
				available_nodes[sp].push_back(i);	/* Add second competing node */
				i = i + 1;
				
				int *cumm_intr_count = new int[number_sp];
				cumm_intr_count[0] = num_intr[sp * number_sp + 0];
				for(int int_sp = 1; int_sp <= number_sp - 1; int_sp++) cumm_intr_count[int_sp] = cumm_intr_count[int_sp - 1] +
																										num_intr[sp * number_sp + int_sp];
				for(int ind = 1; ind <= max_num_intr_sp; ind++)	{
					for(int int_sp = 0; int_sp <= number_sp - 1; int_sp++)	{
						if(ind <= cumm_intr_count[int_sp]) {
							available_nodes[int_sp].push_back(i);	/* Add interacting node	*/
							break;
						}
					}
					i = i + 1;
				}
				delete[] cumm_intr_count;
																									//std::cout << "event 2: out" << std::endl;
		}
		else if(prelim_graph_events[i] == 4.0)	{													//std::cout << "event 4: in" << std::endl;
				/* Recombination 	*/
				
				sp_ID[i] = int(prelim_graph_sp[i]);
				sp_ID[i + 1] = int(prelim_graph_sp[i + 1]);
				int sp = sp_ID[i];
				
				/* Choose node that descends from recombining nodes	*/
				int indx = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
					ancestor1[available_nodes[sp].at(indx)] = i;
					ancestor2[available_nodes[sp].at(indx)] = i + 1;
					
					node_event[available_nodes[sp].at(indx)] = 4;
				
				/* Link first recombining node to its descendant */
				desc1[i] = available_nodes[sp].at(indx);
				desc2[i] = -1;
				
				/* Link second recombining node to its descendant */
				desc1[i + 1] = available_nodes[sp].at(indx);
				
				available_nodes[sp].erase(available_nodes[sp].begin() + indx);	/* Delete descendant node */
				
				/* Is second node from outside of graph?  If not connect desc2 to graph. */
				if(prelim_graph_node_in_graph[i + 1] == 1.0)	{
					
					int indx2 = RandomUniformInt(rand_num[rand_indx],0,available_nodes[sp].size() - 1);	rand_indx = rand_indx + 1;
					desc2[i + 1] = available_nodes[sp].at(indx2);
					
					ancestor1[available_nodes[sp].at(indx2)] = i + 1;
					node_event[available_nodes[sp].at(indx2)] = 1;
					
					available_nodes[sp].erase(available_nodes[sp].begin() + indx2);	/* Delete descendant node */
					
				}
				else	{
					desc2[i + 1] = -1;
				}
				
				/* Initialize ancestors of recombining nodes	*/
				ancestor1[i] = -1;
				ancestor2[i] = -1;
				
				acc_genotype_updated[i] = 0;
				
				ancestor1[i + 1] = -1;
				ancestor2[i + 1] = -1;
				
				acc_genotype_updated[i + 1] = 0;
				
				available_nodes[sp].push_back(i);	/* Add first recombining node */
				i = i + 1;
				available_nodes[sp].push_back(i);	/* Add second recombining node */
				i = i + 1;
				
		}
		else	{
			std::cout << "Error determining if a coal or selection event occurred in Connect Graph." << std::endl;
			exit(8);
		}
	}
	
	for(int sp = 0; sp <= number_sp - 1; sp++)	{
		available_nodes[sp].clear();
		tmp_available_nodes[sp].clear();
	}
	
	delete [] tmp_available_nodes;
	delete [] available_nodes;
	
	std::cout << "Exiting connect_graph" << std::endl;
	return;
}		