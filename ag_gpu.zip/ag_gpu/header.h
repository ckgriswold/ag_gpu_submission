#include<vector>
#include "dc.h"

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

int gpu_graph(int number_sp, int *sample_size, float *sel_coef, float *r, int *num_intr, float t_max, float *ne, float *gamma,
				float *acc_mu_gain, float *acc_mu_loss, int num_acc_chr, int num_acc_reg, float *g_mu, 
				int num_core_chr, int num_core_reg,
				int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores,
				int graph_cycles_mult, int block_size,
				float *a, int *opt_acc_genotype, int hgt_or_rec, float alpha,
				int *&sp_ID, int *&desc1, int *&desc2, int *&ancestor1, int *&ancestor2, int *&intr_ind,
				int **&acc_genotype, int **&core_genotype_1, int **&core_genotype_2,
				
				cl_context context_rnd_uniform, cl_command_queue command_queue_rnd_uniform,
  				cl_program program_rnd_uniform, cl_kernel kernel_rnd_uniform,
  				
  				cl_context context_net_gain_loss, cl_command_queue command_queue_net_gain_loss,
  				cl_program program_net_gain_loss, cl_kernel kernel_net_gain_loss,
  				
  				cl_context context_mut, cl_command_queue command_queue_mut,
  				cl_program program_mut, cl_kernel kernel_mut,
  				
  				cl_context context_calc_k, cl_command_queue command_queue_calc_k,
  				cl_program program_calc_k, cl_kernel kernel_calc_k,
  				
  				cl_context context_time_to_anc, cl_command_queue command_queue_time_to_anc,
  				cl_program program_time_to_anc, cl_kernel kernel_time_to_anc,
  				
  				cl_context context_acc, cl_command_queue command_queue_acc,
  				cl_program program_acc, cl_kernel kernel_acc
				);

void make_prelim_graph(std::vector< float* > *tree, int number_sp, int *sample_size, float *sel_coef, float *r, int *num_intr, float t_max, 
						float *ne, float *gamma, int *num_coal, int *num_sel, int *num_rec, int *num_other,
						int block_size, std::vector< int* > *block_start_stop);

void connect_graph(float *prelim_graph_events, float *prelim_graph_sp, float *prelim_graph_node_in_graph, 
					int graph_size, int number_sp, int num_acc_chr, int num_acc_reg, int *num_intr, 
						int *sp_ID, int *desc1, int *desc2, int *ancestor1, int *ancestor2,
							int *intr_ind, int *acc_genotype_updated, int **acc_genotype, float *rand_num, int max_num_intr, int *node_event);

void create_kernel_cl(cl_context *context, cl_command_queue *command_queue, cl_program *program, cl_kernel *kernel, cl_device_type CL_DEVICE_TYPE_X,
		char *kernel_file, char *kernel_func);
		
void time_to_anc_cl(float *prelim_graph_node_time, int block_size, int block_start, int *ancestor, float **time_to_anc,
							cl_context context,cl_command_queue command_queue,cl_program program,cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores);
		
void calc_rand_uniform_cl(int graph_size, float **delta_rand_uniform,
							cl_context context,cl_command_queue command_queue,cl_program program,cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores);

void calc_k_cl(float *time_to_anc, int graph_size, int number_sp, int *sp_ID, float *mu, float *rnd_uniform_1, float *rnd_uniform_2, int **k,
							cl_context context, cl_command_queue command_queue, cl_program program, cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores);
								
void calc_mut_cl(int num_k, int **mut_lst, int min, int max, float *rnd_uniform,
							cl_context context, cl_command_queue command_queue, cl_program program, cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores);
								
void calc_net_gain_loss_cl(int block_size, int *sum_k_acc, int sum_k_acc_tot, int *k_acc, int number_sp, int *sp_ID, int *acc_mut_lst, 
							int min, int max, 
							float *mu_gain, float *mu_loss, float *rand_num_1, float *rand_num_2,
							cl_context context, cl_command_queue command_queue, cl_program program, cl_kernel kernel,
								int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores);

void calc_acc_genotype_cl(int block_size, int block_start, int block_stop,
				int number_sp,
				int *sp_ID, int *acc_genotype, int *acc_genotype_updated, 
				int *ancestor1, int *ancestor2, int *intr_ind,
				int num_acc_reg, int *num_intr, int max_num_intr,
				int *k_1_acc, int *k_2_acc, int *mut_1_acc, int *mut_2_acc,
				int *k_1_core, int *k_2_core, int *mut_1_core, int *mut_2_core, int *genotype_1, int *genotype_2, int num_core_reg,
				int num_mut_1_acc, int num_mut_2_acc, int *sum_k_1_acc, int *sum_k_2_acc,
				int num_mut_1_core, int num_mut_2_core, int *sum_k_1_core, int *sum_k_2_core,
				cl_context context,cl_command_queue command_queue,cl_program program,cl_kernel kernel,
				int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores,
                int graph_cycles_mult,
                float *a, int *opt_genotype, float alpha,
                float *rand_uniform_1, int *block_node_event, int hgt_or_rec, float *rand_uniform_2, int num_rec);

