#include<stdlib.h>
#include<stdio.h>
#include<new>
#include<vector>
#include<time.h>
#include<iostream>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

#include"header.h"

int gpu_graph(int number_sp, int *sample_size, float *sel_coef, float *r, int *num_intr, float t_max, float *ne, float *gamma,
				float *acc_mu_gain, float *acc_mu_loss, int num_acc_chr, int num_acc_reg, float *g_mu, 
				int num_core_chr, int num_core_reg,
				int gpu_local_item_size, int gpu_global_item_size, int gpu_num_cores,
				int graph_cycles_mult, int block_size,
				float *a, int *opt_acc_genotype, int hgt_or_rec, float alpha,
				int *&sp_ID, int *&desc1, int *&desc2, int *&ancestor1, int *&ancestor2, int *&intr_ind,
				int **&acc_genotype, int **&core_genotype_1, int **&core_genotype_2,
				
				cl_context context_rnd_uniform, cl_command_queue command_queue_rnd_uniform,
  				cl_program program_rnd_uniform, cl_kernel kernel_rnd_uniform,
  				
  				cl_context context_net_gain_loss, cl_command_queue command_queue_net_gain_loss,
  				cl_program program_net_gain_loss, cl_kernel kernel_net_gain_loss,
  				
  				cl_context context_mut, cl_command_queue command_queue_mut,
  				cl_program program_mut, cl_kernel kernel_mut,
  				
  				cl_context context_calc_k, cl_command_queue command_queue_calc_k,
  				cl_program program_calc_k, cl_kernel kernel_calc_k,
  				
  				cl_context context_time_to_anc, cl_command_queue command_queue_time_to_anc,
  				cl_program program_time_to_anc, cl_kernel kernel_time_to_anc,
  				
  				cl_context context_calc_acc, cl_command_queue command_queue_calc_acc,
  				cl_program program_calc_acc, cl_kernel kernel_calc_acc
				
				) {
		
		/* Setup prelim_graph data object, which is a c++ vector of pointers to floats 								*/
		/* Each element in the vector will be a 4-dimensional array that consisting of the time of an event in the  */
		/* graph, the type of event that occurred, the species/label and an indicator variable						*/
		std::vector< float* > *prelim_graph;
		prelim_graph = new std::vector< float* >;
		
		/* Setup a c++ vector that stores the beginning and end positions of slices of the ancestral graph */
		std::vector< int* > *block_start_stop;
		block_start_stop = new std::vector< int* >;
		
		int tot_sample_size = 0;
		for(int i = 0; i <= number_sp - 1; i++)	tot_sample_size = tot_sample_size + sample_size[i]; 
		
		int num_coal;
		int num_sel;
		int num_rec;
		int num_other;

		/* The make_prelim_graph function generates information in the prelim_graph data object 					*/
		make_prelim_graph(prelim_graph, number_sp, sample_size, sel_coef, r, num_intr, t_max, ne, gamma, &num_coal, &num_sel, &num_rec, &num_other,
							block_size, block_start_stop);		
		
		std::cout << prelim_graph->size() * sizeof(int) <<  std::endl;
		std::cout << block_size * num_acc_chr * num_acc_reg * sizeof(int) << " " << block_size * num_core_chr * num_core_reg * sizeof(int) <<   std::endl;
		
		/* A check for whether the graph and its contents will be too big for the memory capacity of a computer.  	*/					
		if(prelim_graph->size() * 4 >  2147483647 || prelim_graph->size() * 4 >  2147483647)	{
			std::cout << "The graph size is too large." << std::endl;
			std::cout << "Reduce the rate of selection or number of interacting individuals." << std::endl;
			exit(8);
		}
		
		/* Set up data objects for ancestral graph, which is represented by a set of vectors.						*/
		sp_ID = new int[prelim_graph->size()];												/* Species or label ids	of nodes	*/
		desc1 = new int[prelim_graph->size()];												/* One descendent of node			*/
		desc2 = new int[prelim_graph->size()];												/* Second descent of node			*/
		ancestor1 = new int[prelim_graph->size()];											/* One ancestor of node				*/
		ancestor2 = new int[prelim_graph->size()];											/* Second ancestor of node			*/
		
		int max_num_intr = 0; 
		for(int sp = 0; sp <= number_sp - 1; sp++)	{
			int tmp_loc = 0;
			for(int int_sp = 0; int_sp <= number_sp - 1; int_sp++)	{
				tmp_loc = tmp_loc + num_intr[sp * number_sp + int_sp];
			}
			if(max_num_intr < tmp_loc) max_num_intr = tmp_loc;
		}
		intr_ind = new int[prelim_graph->size() * max_num_intr];							/* Interacting individuals of node	*/
		
		acc_genotype = new int*[prelim_graph->size()];										/* Accessory genome of node			*/
		int *acc_genotype_updated = new int[prelim_graph->size()];
		
		core_genotype_1 = new int*[prelim_graph->size()];									/* Core genome of node from ancestor 1	*/
		core_genotype_2 = new int*[prelim_graph->size()];									/* Core genome of node from ancestor 2	*/
	
		float *rand_uniform_1;
		int tot_num_events;
		tot_num_events = 2 * num_coal + (2 + max_num_intr) * num_sel + num_rec + num_other;
		
		/* Here, a GPU kernel will be used for the first time.  It generates a large vector of uniform random deviates	*/
		/* that will be used in the connect_graph function.																*/
		calc_rand_uniform_cl(tot_num_events, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);

		float *prelim_graph_node_event = new float[prelim_graph->size()];
		float *prelim_graph_node_sp = new float[prelim_graph->size()];
		float *prelim_graph_node_in_graph = new float[prelim_graph->size()];
		int *node_event = new int[prelim_graph->size()];
		for(int i = 0; i <= prelim_graph->size() - 1; i++) {
			prelim_graph_node_event[i] = prelim_graph->at(i)[1];
			prelim_graph_node_sp[i] = prelim_graph->at(i)[2];
			prelim_graph_node_in_graph[i] = prelim_graph->at(i)[3];
			node_event[i] = 0;
		}
		
		/* The connect_graph function takes the prelim_graph information about times of an event and the type of event	*/
		/* and then generates the graph with nodes connected by edges.													*/
		connect_graph(prelim_graph_node_event, prelim_graph_node_sp, prelim_graph_node_in_graph, prelim_graph->size(), 
						number_sp, num_acc_chr, num_acc_reg, num_intr, sp_ID, desc1, desc2, ancestor1, ancestor2, intr_ind, 
						acc_genotype_updated, acc_genotype, rand_uniform_1, max_num_intr, node_event);
						
		delete[] rand_uniform_1;
		
		int flag_acc = 0;	int flag_core = 0;		/* Flags for rare GPU errors */
		
		/* Now we work from the bottom of the graph upwards in sections to determine the state of nodes.  This is 		*/
		/* done in sections of the graph defined by the block_start_stop vector that was previously generated.			*/
		for(int blk = block_start_stop->size() - 1; blk >= 0; blk--)	{
			
			flag_acc = 0;	flag_core = 0;
			
			block_size = block_start_stop->at(blk)[1] - block_start_stop->at(blk)[0];
			
			int block_start = block_start_stop->at(blk)[0];
			int block_stop = block_start_stop->at(blk)[1];
			
			std::cout << block_start << " " << block_stop << " " << prelim_graph->size() << " " << block_size << std::endl;
			
			float *prelim_graph_node_time = new float[block_size];
	
			for(int i = 0; i <= block_size - 1; i++)	
				prelim_graph_node_time[i] = prelim_graph->at(i + block_start)[0];
				
			int *block_node_event = new int[block_size];
			for(int i = 0; i <= block_size - 1; i++)	
				block_node_event[i] = node_event[i + block_start];
			
			/* Get times along edges that connect nodes using the GPU kernel time_to_anc.cl							*/
			float *time_to_anc_1;
			float *time_to_anc_2;
			
			int *block_ancestor = new int[block_size];
			for(int i = 0; i <= block_size - 1; i++)	
				block_ancestor[i] = ancestor1[i + block_start] - block_start;
		
			time_to_anc_cl(prelim_graph_node_time, block_size, block_start, block_ancestor, &time_to_anc_1,
								context_time_to_anc, command_queue_time_to_anc, program_time_to_anc, kernel_time_to_anc,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
								
			delete[] block_ancestor;
			block_ancestor = new int[block_size];
			for(int i = 0; i <= block_size - 1; i++)	
				block_ancestor[i] = ancestor2[i + block_start] - block_start;
							
			time_to_anc_cl(prelim_graph_node_time, block_size, block_start, block_ancestor, &time_to_anc_2,
								context_time_to_anc, command_queue_time_to_anc, program_time_to_anc, kernel_time_to_anc,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* Next, generate two arrays of uniform deviates that will then be used to generate the number of gain/losses or mutations		*/
			/* along an edge in the graph.  This uses the MWC64X.cl kernel	of Thomas called through the calc_rand_uniform_cl function		*/
			float *rand_uniform_2;
		
			calc_rand_uniform_cl(block_size, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_size, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* Using the uniform deviates.  The GPU is then used to generate the number of gain/loss or mutations events along an edge that	*/
			/* affect the accessory genotype. Uses total gain/loss rate to get number of events, then determines overall gain/loss 			*/
			/* sequence.																													*/
			int *block_sp_ID = new int[block_size];
			for(int i = 0; i <= block_size - 1; i++) {
				block_sp_ID[i] = sp_ID[block_start + i];
				if(block_sp_ID[i] >  number_sp - 1) {
					std::cout << "Error with sp_ID " << i << std::endl;
					exit(8);
				}
			}
			
			int *k_1_acc;
			int *k_2_acc;
			
			int *mut_1_acc_lst;
			int *mut_2_acc_lst;
			
			int min;
			int max;
			
			float *acc_mu_total = new float[number_sp];
			for(int i = 0; i <= number_sp - 1; i++) acc_mu_total[i] = acc_mu_gain[i] + acc_mu_loss[i];
		
			calc_k_cl(time_to_anc_1, block_size, number_sp, block_sp_ID, acc_mu_total, rand_uniform_1, rand_uniform_2, &k_1_acc,
							context_calc_k, command_queue_calc_k,program_calc_k,kernel_calc_k,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
								
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			calc_rand_uniform_cl(block_size, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_size, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			calc_k_cl(time_to_anc_2, block_size, number_sp, block_sp_ID, acc_mu_total, rand_uniform_1, rand_uniform_2, &k_2_acc,
							context_calc_k, command_queue_calc_k,program_calc_k,kernel_calc_k,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* Locations of gain/loss in the accessory genotype are then determined								  	*/
			int block_tot_k_1_acc = 0;
			int block_tot_k_2_acc = 0;
		
			int *block_sum_k_1_acc = new int[block_size];
			int *block_sum_k_2_acc = new int[block_size];
			
			for(int i = 0; i <= block_size - 1; i++) {
				block_sum_k_1_acc[i] = block_tot_k_1_acc;
				block_tot_k_1_acc = block_tot_k_1_acc + k_1_acc[i];
				
				block_sum_k_2_acc[i] = block_tot_k_2_acc;
				block_tot_k_2_acc = block_tot_k_2_acc + k_2_acc[i];

			}	
			
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			if(block_tot_k_1_acc >=0 && block_tot_k_2_acc >= 0 
					&& block_tot_k_1_acc < 2147483647 && block_tot_k_2_acc < 2147483647) flag_acc = 1;
			
		if(flag_acc == 1)	{
			calc_rand_uniform_cl(block_tot_k_1_acc, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_tot_k_1_acc, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* The accessory genome is divided into subregions, each consisting of 15 genes.   											*/
			/* Below the GPU is used to generate the locations of gain/loss of these genes or mutations									*/
	
			mut_1_acc_lst = new int[block_tot_k_1_acc];
			mut_2_acc_lst = new int[block_tot_k_2_acc];
		
			min = 1;
			max = 15 * num_acc_reg * num_acc_chr;			/* Max 30, or get negative numbers with bit arithematic	*/

			/* calc_net_gain_loss_cl sets up and calls the GPU kernel that generates the regions/sites with gain/loss of that mutate	*/
			calc_net_gain_loss_cl(block_size, block_sum_k_1_acc, block_tot_k_1_acc, k_1_acc, number_sp, block_sp_ID, mut_1_acc_lst, min, max, 
								acc_mu_gain, acc_mu_loss, rand_uniform_1, rand_uniform_2,
								context_net_gain_loss, command_queue_net_gain_loss, program_net_gain_loss, kernel_net_gain_loss,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			
			calc_rand_uniform_cl(block_tot_k_2_acc, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_tot_k_2_acc, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);					
							
			calc_net_gain_loss_cl(block_size, block_sum_k_2_acc, block_tot_k_2_acc, k_2_acc, number_sp, block_sp_ID, mut_2_acc_lst, min, max, 
								acc_mu_gain, acc_mu_loss, rand_uniform_1, rand_uniform_2,
								context_net_gain_loss, command_queue_net_gain_loss, program_net_gain_loss, kernel_net_gain_loss,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
		}
			
			/* Next, uniform deviates and the number of mutations affecting the core/marker genotype are generated on the GPU	*/		
			int *k_1_core;
			int *k_2_core;
			
			int *mut_1_core_lst;
			int *mut_2_core_lst;
			
			calc_rand_uniform_cl(block_size, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_size, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
		
			calc_k_cl(time_to_anc_1, block_size, number_sp, block_sp_ID, g_mu, rand_uniform_1, rand_uniform_2, &k_1_core,
							context_calc_k, command_queue_calc_k,program_calc_k,kernel_calc_k,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
								
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			calc_rand_uniform_cl(block_size, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_size, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);					
								
			calc_k_cl(time_to_anc_2, block_size, number_sp, block_sp_ID, g_mu, rand_uniform_1, rand_uniform_2, &k_2_core,
							context_calc_k, command_queue_calc_k,program_calc_k,kernel_calc_k,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);				
								
			int block_tot_k_1_core = 0;
			int block_tot_k_2_core = 0;
		
			int *block_sum_k_1_core = new int[block_size];
			int *block_sum_k_2_core = new int[block_size];
			
			for(int i = 0; i <= block_size - 1; i++) {
				block_sum_k_1_core[i] = block_tot_k_1_core;
				block_tot_k_1_core = block_tot_k_1_core + k_1_core[i];
				
				block_sum_k_2_core[i] = block_tot_k_2_core;
				block_tot_k_2_core = block_tot_k_2_core + k_2_core[i];
				
			}	
			
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			if(block_tot_k_1_core >=0 && block_tot_k_2_core >= 0 
					&& block_tot_k_1_core < 2147483647 && block_tot_k_2_core < 2147483647) flag_core = 1;
			
			
		if(flag_core == 1)	{	
			calc_rand_uniform_cl(block_tot_k_1_core, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_rand_uniform_cl(block_tot_k_2_core, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* The sequenced region is divided into regions, each consisting of 15 sites.  The total length of the 				*/
			/* genomic region that is sequenced is num_reg * 15.  Below the GPU is used to generat the locations of mutations	*/
			/* in the genome.																									*/
		
			min = 1;
			max = 15 * num_core_reg * num_core_chr;			/* Max 30, or get negative numbers with bit arithematic	*/
	
			/* calc_mut_cl sets up and calls the GPU kernel that generates the sites that mutate.							*/
			calc_mut_cl(block_tot_k_1_core, &mut_1_core_lst, min, max, rand_uniform_1,
								context_mut, command_queue_mut, program_mut, kernel_mut,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			calc_mut_cl(block_tot_k_2_core, &mut_2_core_lst, min, max, rand_uniform_2,
								context_mut, command_queue_mut, program_mut, kernel_mut,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
		
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;

		}

			/* Here the GPU is used to generated uniform deviates that will be used to determine which lineage wins			*/
			/* selection events or recombination points																		*/
			calc_rand_uniform_cl(block_size, &rand_uniform_1, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
			
			/* Here the GPU is used to generated uniform deviates that will be used to determine the						*/
			/* orientation of the recombination event																		*/
			calc_rand_uniform_cl(block_size, &rand_uniform_2, 
								context_rnd_uniform, command_queue_rnd_uniform, program_rnd_uniform, kernel_rnd_uniform,
								gpu_local_item_size, gpu_global_item_size, gpu_num_cores);
		
		if(flag_acc == 1 && flag_core == 1)	{
			/* Here the section of the graph that will be sent to the GPU to calculate phenotypes and genotypes is generated.	*/
			int *block_ancestor1 = new int[block_size];
			int *block_ancestor2 = new int[block_size];
			int *block_intr_ind = new int[block_size * max_num_intr];
		
			int *block_acc_genotype = new int[block_size * num_acc_chr * num_acc_reg];
			int *block_acc_genotype_updated = new int[block_size];
			
			int *block_genotype_1 = new int[block_size * num_core_chr *num_core_reg];
			int *block_genotype_2 = new int[block_size * num_core_chr *num_core_reg];
			
			std::cout << "Assigning block ancestors and initializing genotypes" << std::endl;
			for(int i = 0; i <= block_size - 1; i++)	{
				
				if(ancestor1[i + block_start] == -1)
					block_ancestor1[i] = -1;
				else
					block_ancestor1[i] = ancestor1[i + block_start] - block_start;
				
				if(ancestor2[i + block_start] == -1)
					block_ancestor2[i] = -1;
				else
					block_ancestor2[i] = ancestor2[i + block_start] - block_start;
			
				for(int ind = 0; ind <= max_num_intr - 1; ind++)	{

					if(intr_ind[i * max_num_intr + ind + block_start * max_num_intr] == -1)
						block_intr_ind[i * max_num_intr + ind] = -1;
					else
						block_intr_ind[i * max_num_intr + ind] = 
							intr_ind[i * max_num_intr + ind + block_start * max_num_intr] - block_start;

				}
				
				if(acc_genotype_updated[i + block_start] < 1 || node_event[block_start + i] == 0)	{
				
					acc_genotype[(block_start + i)] = new int[num_acc_chr * num_acc_reg];
					
					for(int chr = 0; chr <= num_acc_chr - 1; chr++)	{
						for(int reg = 0; reg <= num_acc_reg - 1; reg++)	{
							acc_genotype[(block_start + i)][chr * num_acc_reg + reg] = 0;
							block_acc_genotype[i * num_acc_chr * num_acc_reg + num_acc_reg * chr + reg] = 0;
						}
					}
					
					core_genotype_1[(block_start + i)] = new int[num_core_chr * num_core_reg];
					core_genotype_2[(block_start + i)] = new int[num_core_chr * num_core_reg];
				
					for(int chr = 0; chr <= num_core_chr - 1; chr++)	{
						for(int j = 0; j <= num_core_reg - 1; j++)	{
							core_genotype_1[(i + block_start)][chr * num_core_reg + j] = 0;
							core_genotype_2[(i + block_start)][chr * num_core_reg + j] = 0;
						}
					}
				}
				else if(acc_genotype_updated[i + block_start] > 0)	{
					
					for(int chr = 0; chr <= num_acc_chr - 1; chr++)	{
						for(int reg = 0; reg <= num_acc_reg - 1; reg++)	{
							block_acc_genotype[i * num_acc_chr * num_acc_reg + num_acc_reg * chr + reg] = 
									acc_genotype[block_start + i][chr * num_acc_reg + reg];
						}
					}
					
					for(int chr = 0; chr <= num_core_chr - 1; chr++)	{
						for(int j = 0; j<= num_core_reg - 1; j++)	{
							block_genotype_1[i * num_core_chr * num_core_reg + chr * num_core_reg + j] = 
															core_genotype_1[block_start + i][chr * num_core_reg + j];
							block_genotype_2[i * num_core_chr * num_core_reg + chr * num_core_reg + j] = 
															core_genotype_2[block_start + i][chr * num_core_reg + j];
						}
					}
				
				}
				else { /* Do Nothing */}
					
				block_acc_genotype_updated[i] = acc_genotype_updated[i + block_start];
				
			}
			std::cout << "Exit assigning block ancestors and initializing genotypes" << std::endl;
			
			/* Here calc_acc_genotype_cl sets up and calls the GPU kernel that works up through a graph section and calculates	*/
			/* core/marker genotypes, accessory genotypes and which lineages when selection events								*/
			calc_acc_genotype_cl(block_size, block_start, block_stop,
						number_sp,
						block_sp_ID, block_acc_genotype, block_acc_genotype_updated, 
						block_ancestor1, block_ancestor2, block_intr_ind,
						num_acc_chr * num_acc_reg, num_intr, max_num_intr,
						k_1_acc, k_2_acc, mut_1_acc_lst, mut_2_acc_lst, 
						k_1_core, k_2_core, mut_1_core_lst, mut_2_core_lst, 
						block_genotype_1, block_genotype_2, num_core_chr * num_core_reg,
						block_tot_k_1_acc, block_tot_k_2_acc, block_sum_k_1_acc, block_sum_k_2_acc,
						block_tot_k_1_core, block_tot_k_2_core, block_sum_k_1_core, block_sum_k_2_core,
						context_calc_acc,command_queue_calc_acc,program_calc_acc,kernel_calc_acc,
						gpu_local_item_size, gpu_global_item_size, gpu_num_cores,graph_cycles_mult,
						a, opt_acc_genotype, alpha,
						rand_uniform_1, block_node_event, hgt_or_rec, rand_uniform_2, num_rec);
			
			/* Block information is copied back to the base data objects that represent the graph.					*/		
			std::cout << "Copying information back from GPU" << std::endl;
			for(int i = 0; i <= block_size - 1; i++)	{
				int test = 0;
				
				if(block_start + i <= tot_sample_size - 1) test = 1;
				
				if(test < 1)	{
					if(blk > 0)	{
						if(node_event[desc1[block_start + i]] == 3 && desc1[block_start + i] < block_start)	
							test = 1;
						else 
							test = test;
					}
					else test = test;
				}
				else
					test = test;
			
				if(test == 1)	{
				
				for(int chr = 0; chr <= num_acc_chr - 1; chr++)	{
					for(int reg = 0; reg <= num_acc_reg - 1; reg++)	{
						acc_genotype[block_start + i][chr * num_acc_reg + reg] = 
									block_acc_genotype[i * num_acc_chr * num_acc_reg + chr * num_acc_reg + reg];
					}
				}
				acc_genotype_updated[i + block_start] = block_acc_genotype_updated[i];
				
				for(int chr = 0; chr <= num_core_chr - 1; chr++)	{
					for(int j = 0; j<= num_core_reg - 1; j++)	{
						core_genotype_1[(i + block_start)][chr * num_core_reg + j] = 
								block_genotype_1[i * num_core_chr * num_core_reg + chr * num_core_reg + j];
						core_genotype_2[(i + block_start)][chr * num_core_reg + j] = 
								block_genotype_2[i * num_core_chr * num_core_reg + chr * num_core_reg + j];
					}
				}
				
				}
				else	{
					
					acc_genotype_updated[i + block_start] = block_acc_genotype_updated[i];
						
					delete[] acc_genotype[block_start + i];
					delete[] core_genotype_1[(i + block_start)];
					delete[] core_genotype_2[(i + block_start)];
					
					
				}

			}
			std::cout << "Exit copying information back from GPU" << std::endl;
			
			delete[] acc_mu_total;
			
			delete[] block_genotype_1;
			delete[] block_genotype_2;
			delete[] block_intr_ind;
			delete[] block_ancestor1;
			delete[] block_ancestor2;
			delete[] block_acc_genotype_updated;
			delete[] block_acc_genotype;
			delete[] block_sp_ID;
			
			delete[] mut_1_acc_lst;
			delete[] mut_2_acc_lst;
			
			delete[] block_sum_k_1_acc;
			delete[] block_sum_k_2_acc;
			
			delete[] mut_1_core_lst;
			delete[] mut_2_core_lst;
			
			delete[] block_sum_k_1_core;
			delete[] block_sum_k_2_core;
			
			delete[] k_1_acc;
			delete[] k_2_acc;
			
			delete[] k_1_core;
			delete[] k_2_core;
			
			delete[] time_to_anc_1;
			delete[] time_to_anc_2;
			
			delete[] rand_uniform_1;
			delete[] rand_uniform_2;
			
			delete[] block_ancestor;
			
			delete[] prelim_graph_node_time;
			delete[] block_node_event;
		}
		else if(flag_acc == 0 && flag_core == 1)	{

			delete[] acc_mu_total;
			
			delete[] block_sp_ID;
			
			delete[] mut_1_core_lst;
			delete[] mut_2_core_lst;
			
			delete[] block_sum_k_1_core;
			delete[] block_sum_k_2_core;
			
			delete[] k_1_core;
			delete[] k_2_core;
			
			delete[] time_to_anc_1;
			delete[] time_to_anc_2;
			
			delete[] block_ancestor;
			
			delete[] prelim_graph_node_time;
			delete[] block_node_event;
		
			if(blk < block_start_stop->size() - 1)	{
				for(int i = 0; i <= block_size - 1; i++)	{
				
					int test = 0;
				
					if(test < 1)	{
						if(blk >= 0 && desc1[block_start + i] >= 0)	{
							if(node_event[desc1[block_start + i]] == 3 && desc1[block_start + i] >= block_start)	
								test = 1;
							else 
								test = test;
						}
						else test = test;
					}
					else
						test = test;
					
					if(test == 1)	{
					
						delete[] acc_genotype[block_start + i];
						delete[] core_genotype_1[(i + block_start)];
						delete[] core_genotype_2[(i + block_start)];
						
					}
				}
			}
		
			break;
		}
		else if(flag_acc == 1 && flag_core == 0)	{

			delete[] acc_mu_total;
			
			delete[] block_sp_ID;
			
			delete[] mut_1_acc_lst;
			delete[] mut_2_acc_lst;
			
			delete[] block_sum_k_1_acc;
			delete[] block_sum_k_2_acc;
			
			delete[] k_1_acc;
			delete[] k_2_acc;
			
			delete[] time_to_anc_1;
			delete[] time_to_anc_2;
			
			delete[] block_ancestor;
			
			delete[] prelim_graph_node_time;
			delete[] block_node_event;
		
			if(blk < block_start_stop->size() - 1)	{
				for(int i = 0; i <= block_size - 1; i++)	{
				
					int test = 0;
				
					if(test < 1)	{
						if(blk >= 0 && desc1[block_start + i] >= 0)	{
							if(node_event[desc1[block_start + i]] == 3 && desc1[block_start + i] >= block_start)	
								test = 1;
							else 
								test = test;
						}
						else test = test;
					}
					else
						test = test;
					
					if(test == 1)	{
									
						delete[] acc_genotype[block_start + i];
						delete[] core_genotype_1[(i + block_start)];
						delete[] core_genotype_2[(i + block_start)];
						
					}
				}
			}
			
			break;
		}
		else {
			delete[] acc_mu_total;
			
			delete[] block_sp_ID;
			
			delete[] time_to_anc_1;
			delete[] time_to_anc_2;
			
			delete[] block_ancestor;
			
			delete[] prelim_graph_node_time;
			delete[] block_node_event;
			
			if(blk < block_start_stop->size() - 1)	{
				for(int i = 0; i <= block_size - 1; i++)	{
					
					int test = 0;
				
					if(test < 1)	{
						if(blk >= 0 && desc1[block_start + i] >= 0)	{
							if(node_event[desc1[block_start + i]] == 3 && desc1[block_start + i] >= block_start)	
								test = 1;
							else 
								test = test;
						}
						else test = test;
					}
					else
						test = test;
					
					if(test == 1)	{
						
						delete[] acc_genotype[block_start + i];
						delete[] core_genotype_1[(i + block_start)];
						delete[] core_genotype_2[(i + block_start)];
						
					}
				}
			}
			
			break;
		}
		
		}	
		
		delete[] prelim_graph_node_event;
		delete[] prelim_graph_node_sp;
		delete[] prelim_graph_node_in_graph;
		delete[] acc_genotype_updated;
		delete[] node_event;
		
		int graph_size = prelim_graph->size();
		for(int i = 0; i <= prelim_graph->size() - 1; i++)
			delete prelim_graph->at(i);
		
		for(int i = 0; i <= block_start_stop->size() - 1; i++)
			delete block_start_stop->at(i);
			
		delete prelim_graph;
		delete block_start_stop;
		
		std::cout << "k flag: " << flag_acc << " " << flag_core << std::endl;
		
		if(flag_acc == 1 && flag_core == 1)	
			return graph_size;
		else 
			return 0;
}
