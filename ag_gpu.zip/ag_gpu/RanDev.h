int RandomUniformInt(float rand_num, int min, int max);
