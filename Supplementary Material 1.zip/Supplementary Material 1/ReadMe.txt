Folders o_# contain simulation results when the following genotypes were optimal:

# = 5: [2,2,2,2,2,0,0,0, . . .]

# = 10: [2,2,2,2,2,2,2,2,2,2,0,0,0, . . .]

# = 20: [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0, . . .]

Genotypes of individuals are in the file Data.out to verify optimal genotypes are selected for.