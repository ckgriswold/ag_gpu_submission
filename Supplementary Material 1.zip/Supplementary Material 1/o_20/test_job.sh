#!/bin/bash
#SBATCH --account=def-cgriswol
#SBATCH --gres=gpu:p100:1
#SBATCH --mem=32G
#SBATCH --time=0-12:00
./ag_gpu_exe 8181819900
